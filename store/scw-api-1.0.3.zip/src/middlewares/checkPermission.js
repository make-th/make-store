const jwt = require('jsonwebtoken')
const { JWT_SECRET } = require('../config/environment')

module.exports = {
  isAdmin: (req, res, next) => {
    const token =
      req.body.token || req.query.token || req.headers['x-access-token']

    try {
      // verify token
      const decoded = jwt.verify(token, JWT_SECRET)
      const { user } = decoded
      if (user.role.toUpperCase() === 'ADMIN') {
        return next()
      } else {
        return res.status(401).send("You don't have permission.")
      }
    } catch (error) {
      // verify token error
      return res.status(403).json({
        status: 'error',
        error,
      })
    }
  },
}
