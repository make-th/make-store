require('./config/database').connect()
const express = require('express')
const cors = require('cors')
const app = express()
const { APP_PORT } = require('./config/environment')

const fs = require('fs')
const path = require('path')
const morgan = require('morgan')

// log all requests to access.log
app.use(
  morgan(
    'date: ":date",type: :method,url: :url,status: :status,length: :res[content-length],time: :response-time ms',
    {
      stream: fs.createWriteStream(path.join(__dirname, 'access.log'), {
        flags: 'a',
      }),
    }
  )
)

// allow cors origin
app.use(cors())
app.options('*', cors())

// import controllers
const stationController = require('./stations/station.controller')
const authController = require('./controllers/auth.controller')
const dashboardController = require('./controllers/dashboard.controller')
const reportController = require('./controllers/report.controller')
const LogController = require('./controllers/log.controller');

app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// use controllers
app.use(authController)
app.use(stationController)
app.use(dashboardController)
app.use(reportController)
app.use(LogController)

module.exports = app;

//app.listen(APP_PORT, console.log(`Server is running on port : ${APP_PORT}`))
