const moment = require('moment')
const { v4: uuidv4 } = require('uuid')
const Transaction = require('../models/Transaction')
const Traffic = require('../models/Traffic')

// 1 Report: ข้อมูลกราฟแสดงปริมาณจราจรแยกประเภทขาเข้าขาออก(SummaryTraffic)
const summaryTraffic = async (start, end) => {
  // find object in database
  let _traffics = await Traffic.find({
    stamp: {
      $gte: new Date(start),
      $lt: new Date(end),
    },
  })
    .populate('station', 'name')
    .exec()

  // this gives an object with dates as keys
  const groupDate = _traffics.reduce((groupDate, _) => {
    const date = _.stamp.toISOString().split(':')[0]
    if (!groupDate[date]) {
      groupDate[date] = []
    }
    groupDate[date].push({
      stationName: _.station.name,
      stamp: _.stamp,
      volume: _.volume,
      direction: _.direction,
    })
    return groupDate
  }, {})

  // return array for frontend
  return Object.keys(groupDate).map((_date) => {
    const date = _date.split('T')[0]
    const time = _date.split('T')[1] + ':00'
    const dayName = moment(date).format('ddd')
    return {
      uuid: uuidv4(),
      date,
      Dayname: dayName,
      time,

      TotelLoadIn: groupDate[_date]
        .filter((i) => i.direction === 'in')
        .reduce((sum, x) => sum + x.volume, 0),

      TotelLoadOut: groupDate[_date]
        .filter((i) => i.direction === 'out')
        .reduce((sum, x) => sum + x.volume, 0),
      data: groupDate[_date],
    }
  })
}

// 2 Report : ปริมาณการใช้ทางข้ามอัจฉริยะ   ( SummaryIntelligent )
const summaryIntelligent = async (start, end) => {
  // find object in database
  const _transactions = await Transaction.find(
    {
      stamp: {
        $gte: new Date(start),
        $lt: new Date(end),
      },
    },
    { 'walk.person': 1 }
  )
    .populate('station')
    .exec()

  let arrayList = _transactions.filter((i) => i.walk.person.length > 0)
  let results = []

  for (let i = 0; i < arrayList.length; i++) {
    const elmt1 = arrayList[i]
    const stationName = elmt1.station.name

    for (let j = 0; j < elmt1.walk.person.length; j++) {
      const elmt2 = elmt1.walk.person[j]

      results.push({
        stationName,
        direction: elmt2.direction,
        first_stamp: elmt2.first_stamp,
        last_stamp: elmt2.last_stamp,
        _id: elmt2._id,
      })
    }
  }

  // this gives an object with dates as keys
  const groupDate = results.reduce((groupDate, _) => {
    const date = _.first_stamp.toISOString().split(':')[0]
    if (!groupDate[date]) {
      groupDate[date] = []
    }
    groupDate[date].push(_)
    return groupDate
  }, {})

  // return array for frontend
  return Object.keys(groupDate).map((_date) => {
    const inbound = groupDate[_date].filter((i) => i.direction === 'in').length
    const outbound = groupDate[_date].filter(
      (i) => i.direction === 'out'
    ).length
    const date = _date.split('T')[0]
    const time = _date.split('T')[1] + ':00'
    return {
      uuid: uuidv4(),
      date,
      time,
      TotalIn: inbound,
      TotalOut: outbound,
      data: groupDate[_date],
    }
  })
}

// 3 Report : ปริมาณรถที่ฝ่าฝื่นบนทางข้าม  ( SummaryViolate )
const summaryViolate = async (start, end) => {
  // find object by date query
  const _transactions = await Transaction.find(
    {
      stamp: {
        $gte: new Date(start),
        $lt: new Date(end),
      },
    },
    { 'walk.stamp': 1, 'walk.vehicles': 1 }
  )
    .populate('station')
    .exec()

  let arrayList = _transactions.filter((i) => i.walk.vehicles.length > 0)
  let results = []

  for (let i = 0; i < arrayList.length; i++) {
    const elmt1 = arrayList[i]
    const stationName = elmt1.station.name

    for (let j = 0; j < elmt1.walk.vehicles.length; j++) {
      const elmt2 = elmt1.walk.vehicles[j]

      results.push({
        stationName,
        stamp: elmt2.stamp,
        direction: elmt2.direction,
        lane: elmt2.lane,
        speed: elmt2.speed,
        // license_plate: elmt2.license_plate,
        // province: elmt2.province,
        // _id: elmt2._id,
      })
    }
  }

  // this gives an object with dates as keys
  const groups = results.reduce((groups, _) => {
    const date = _.stamp.toISOString().split(':')[0]
    if (!groups[date]) {
      groups[date] = []
    }
    groups[date].push(_)
    return groups
  }, {})

  // return object for frontend
  return Object.keys(groups).map((_date) => {
    const date = _date.split('T')[0]
    const time = _date.split('T')[1] + ':00'
    const TotalIn = groups[_date].filter((i) => i.direction === 'in').length
    const TotalOut = groups[_date].filter((i) => i.direction === 'out').length
    return {
      uuid: uuidv4(),
      date,
      time,
      TotalIn,
      TotalOut,
      data: groups[_date],
    }
  })
}

// 4 Report : ปริมาณจำนวนคนข้าม ( SummaryPeple )
const summaryPeple = async (start, end) => {
  // find object in database
  const _transactions = await Transaction.find(
    {
      stamp: {
        $gte: new Date(start),
        $lt: new Date(end),
      },
    },
    { 'walk.person': 1 }
  )
    .populate('station')
    .exec()

  let arrayList = _transactions.filter((i) => i.walk.person.length > 0)
  let results = []

  for (let i = 0; i < arrayList.length; i++) {
    const elmt1 = arrayList[i]
    const stationName = elmt1.station.name

    for (let j = 0; j < elmt1.walk.person.length; j++) {
      const elmt2 = elmt1.walk.person[j]

      results.push({
        stationName,
        direction: elmt2.direction,
        first_stamp: elmt2.first_stamp,
        last_stamp: elmt2.last_stamp,
        _id: elmt2._id,
      })
    }
  }

  // this gives an object with dates as keys
  const groupDate = results.reduce((groupDate, _) => {
    const date = _.first_stamp.toISOString().split(':')[0]
    if (!groupDate[date]) {
      groupDate[date] = []
    }
    groupDate[date].push(_)
    return groupDate
  }, {})

  // return array for frontend
  return Object.keys(groupDate).map((_date) => {
    const inbound = groupDate[_date].filter((i) => i.direction === 'in').length
    const outbound = groupDate[_date].filter(
      (i) => i.direction === 'out'
    ).length
    const date = _date.split('T')[0]
    const time = _date.split('T')[1] + ':00'
    return {
      uuid: uuidv4(),
      date,
      time,
      TotalIn: inbound,
      TotalOut: outbound,
      data: groupDate[_date],
    }
  })
}

// 5 Report : แสดงระยะเวลาในการข้าม
const periodOnCrossTheRoad = async (start, end) => {
  const _transactions = await Transaction.find(
    {
      stamp: {
        $gte: new Date(start),
        $lt: new Date(end),
      },
    },
    { 'walk.stamp': 1, 'end.stamp': 1, stamp: 1 }
  )
    .populate('station')
    .exec()

  let results = []
  for (let i = 0; i < _transactions.length; i++) {
    const elmt1 = _transactions[i]
    const stationName = elmt1.station.name
    const diff = moment(elmt1.end.stamp).diff(
      moment(elmt1.walk.stamp),
      'seconds'
    )
    results.push({
      stationName,
      stamp: elmt1.stamp,
      walk: elmt1.walk.stamp,
      end: elmt1.end.stamp,
      TotalInOut: diff,
    })
  }

  const groupDate = results.reduce((groupDate, _) => {
    const date = _.stamp.toISOString().split(':')[0]
    if (!groupDate[date]) {
      groupDate[date] = []
    }
    groupDate[date].push(_)
    return groupDate
  }, {})

  // return array for frontend
  return Object.keys(groupDate).map((_date) => {
    const date = _date.split('T')[0]
    const time = _date.split('T')[1] + ':00'
    const dayName = moment(date).format('ddd')
    return {
      uuid: uuidv4(),
      date,
      dayName,
      time,
      data: groupDate[_date],
    }
  })
}

// 6 Report: แสดงระยะเวลาและจำนวนในการข้าม
const periodAndCountOnCrossTheRoad = async (start, end) => {
  // find object in database
  const _transactions = await Transaction.find(
    {
      stamp: {
        $gte: new Date(start),
        $lt: new Date(end),
      },
    },
    { walk: 1, 'end.stamp': 1, stamp: 1 }
  )
    .populate('station')
    .exec()

  let arrayList = _transactions.filter((i) => i.walk.person.length > 0)
  let results = []

  for (let i = 0; i < arrayList.length; i++) {
    const elmt1 = arrayList[i]
    const stationName = elmt1.station.name

    const diff = moment(elmt1.end.stamp).diff(
      moment(elmt1.walk.stamp),
      'seconds'
    )
    for (let j = 0; j < elmt1.walk.person.length; j++) {
      const elmt2 = elmt1.walk.person[j]

      results.push({
        stationName,
        stamp: elmt1.stamp,
        personCount: {
          direction: elmt2.direction,
          first_stamp: elmt2.first_stamp,
          last_stamp: elmt2.last_stamp,
        },
        timeDiff: {
          walk: elmt1.walk.stamp,
          end: elmt1.end.stamp,
          TotalInOut: diff,
        },
      })
    }
  }

  // this gives an object with dates as keys
  const groupDate = results.reduce((groupDate, _) => {
    const date = _.stamp.toISOString().split(':')[0]
    if (!groupDate[date]) {
      groupDate[date] = []
    }
    groupDate[date].push(_)
    return groupDate
  }, {})

  // return array for frontend
  return Object.keys(groupDate).map((date) => {
    const inbound = groupDate[date].filter(
      (i) => i.personCount.direction === 'in'
    ).length
    const outbound = groupDate[date].filter(
      (i) => i.personCount.direction === 'out'
    ).length
    return {
      uuid: uuidv4(),
      date,
      Total: inbound + outbound,
      TotalIn: inbound,
      TotalOut: outbound,
      data: groupDate[date],
    }
  })
}

module.exports = {
  summaryTraffic,
  summaryIntelligent,
  summaryViolate,
  summaryPeple,
  periodOnCrossTheRoad,
  periodAndCountOnCrossTheRoad,
}
