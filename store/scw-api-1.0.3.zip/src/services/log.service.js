const jwt = require('jsonwebtoken')
const { JWT_SECRET } = require('../config/environment')
const Log = require('../models/Log')

async function getUserIdByToken(req) {
  try {
    const token =
      req.body.token || req.query.token || req.headers['x-access-token']

    const decode = await jwt.verify(token, JWT_SECRET)
    return decode.user._id
  } catch (error) {
    console.log(error)
  }
}

const create = async (req, { title, description }) => {
  try {
    const userId = await getUserIdByToken(req)
    await Log.create({
      title,
      description,
      updatedBy: userId,
    })
  } catch (error) {
    console.log(error)
  }
}

const list = async (req, res) => {
  try {
    const results = await Log.find({}, { __v: 0 })

    if (results) {
      return res.status(200).send(results)
    }

    res.status(404).json({
      message: 'Log in not found.',
    })
  } catch (error) {
    return res.status(400).json({
      error,
    })
  }
}

module.exports = {
  logCreate: create,
  list: list,
}
