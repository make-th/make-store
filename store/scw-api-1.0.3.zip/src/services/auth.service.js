// import bcryprt for encrypt & decrypt password
const bcrypt = require('bcryptjs')

// import jwt for generate access token
const jwt = require('jsonwebtoken')

// import JWT_SECRET for jwt secret key
const { JWT_SECRET } = require('../config/environment')

// import user models
const User = require('../models/User')

module.exports = {
  // register method
  register: async (req, res) => {
    try {
      // destructure body data
      const { username, password, email, role, permission } = req.body

      // encrypt password with bcrypt
      const encryptPassword = await bcrypt.hash(password, 10)

      // create user
      const user = await User.create({
        username,
        password: encryptPassword,
        email,
        role,
        permission,
      })

      // reponse status code 201 when success
      return res.status(201).json({
        user: {
          username: user.username,
          email: user.email,
          role: user.role,
          permission: user.permission,
        },
      })
    } catch (error) {
      return res.status(500).send(error)
    }
  },

  // login methods
  login: async (req, res) => {
    try {
      const { username, password } = req.body

      // find one user by username
      const user = await User.findOne({ username })

      if (user && (await bcrypt.compare(password, user.password))) {
        // create access token
        const token = jwt.sign({ user }, JWT_SECRET, { expiresIn: '1d' })

        // update timestamp login
        await User.findOneAndUpdate({ username }, { lastDate: Date.now() })

        // reponse status code 200 when success
        return res.status(200).json({
          access_token: token,
        })
      }
      return res.status(400).send('Invalid credentials.')
    } catch (error) {
      console.log(error.message)
      return res.status(500).send(error)
    }
  },

  // get data from access token method
  me: async (req, res) => {
    try {
      // destructure _id (user id)
      const { _id } = req.user

      // find user by id
      const user = await User.findById(_id)

      // return status code 200 when success
      return res.status(200).json({
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        permission: user.permission,
        lastDate: user.lastDate,
        status: user.status,
      })
    } catch (error) {
      return res.status(500).send(error)
    }
  },
}
