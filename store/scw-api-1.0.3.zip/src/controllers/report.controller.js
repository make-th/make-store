const route = require('express').Router()
const { body, validationResult } = require('express-validator')
const { verifyToken } = require('../middlewares/authJWT')
const {
  summaryTraffic,
  summaryIntelligent,
  summaryViolate,
  summaryPeple,
  periodOnCrossTheRoad,
  periodAndCountOnCrossTheRoad,
} = require('../services/report.service')

// Report :  ข้อมูลกราฟแสดงปริมาณจราจรแยกประเภทขาเข้าขาออก ( SummaryTraffic)
route.post(
  '/reports/summary-traffic',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end } = req.body
      const results = await summaryTraffic(start, end)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(400).json(error)
    }
  }
)

// Report : ปริมาณการใช้ทางข้ามอัจฉริยะ   ( SummaryIntelligent )
route.post(
  '/reports/summary-intelligent',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end } = req.body
      const results = await summaryIntelligent(start, end)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(400).json(error)
    }
  }
)

// Report : ปริมาณรถที่ฝ่าฝื่นบนทางข้าม   ( SummaryViolate )
route.post(
  '/reports/summary-violate',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end } = req.body
      const results = await summaryViolate(start, end)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(400).json(error)
    }
  }
)

// Report : ปริมาณจำนวนคนข้าม  ( SummaryPeple )
route.post(
  '/reports/summary-peple',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end } = req.body
      const results = await summaryPeple(start, end)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(400).json(error)
    }
  }
)

// Report : แสดงระยะเวลาในการข้าม
route.post(
  '/reports/summary-time-period',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end } = req.body
      const results = await periodOnCrossTheRoad(start, end)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(400).json(error)
    }
  }
)

//Report: แสดงระยะเวลาและจำนวนในการข้าม periodAndCountOnCrossTheRoad
route.post(
  '/reports/summary-count-and-time-period',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end } = req.body
      const results = await periodAndCountOnCrossTheRoad(start, end)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(400).json(error)
    }
  }
)

module.exports = route
