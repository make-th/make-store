const Traffic = require('../models/Traffic')
const Transaction = require('../models/Transaction')

module.exports = {
  createTraffic: async (data, station) => {
    try {
      for (let i = 0; i < data.length; i++) {
        const trf = data[i]
        const results = await Traffic.find({ _id: trf._id }).count()
        if (results === 0) {
          await Traffic.create({
            ...trf,
            station: station._id,
          })
        }
      }
    } catch (err) {
      console.log(err)
    }
  },

  createTransaction: async (data, station) => {
    try {
      for (let i = 0; i < data.length; i++) {
        const trans = data[i]
        const results = await Transaction.find({ _id: trans._id }).count()
        if (results === 0) {
          await Transaction.create({
            ...trans,
            station: station._id,
          })
        }
      }
    } catch (err) {
      console.log(err.message)
    }
  },
}
