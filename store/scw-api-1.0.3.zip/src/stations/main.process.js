const axios = require('axios')
const { createTraffic, createTransaction } = require('./process.service')
const Station = require('../models/Station')
const moment = require('moment')

// fetch function for get data by url endpoint
const fetch = (station) => {
  // date time now and subtract 10 minutes
  const now = new Date()
  const start = moment(now).subtract(10, 'minutes').format('DD-MM-YYYY hh:mm')

  // post data
  // let data = {
  //   startDate: start,
  //   stopDate: moment(now).format('DD-MM-YYYY hh:mm'),
  // } 

  // {
  //   "start": "2022-03-01T00:00:00.000Z",
  //   "end": "2022-03-27T23:59:00.000Z"
  // }

  let data = {
    startDate: "01-01-2022 00:00",
    stopDate: moment(now).format('DD-MM-YYYY hh:mm'),
  }
  // get transaction
  axios
    .post(station.url + '/crosswalk/getReportTransaction', data, {
      headers: {
        'cache-control': 'no-cache',
        'content-type': 'application/json',
        'postman-token': 'd8fc1738-2587-5860-8948-fd7359fe5508',
      },
    })
    .then((results) => {
      const rowCount = results.data.data.length
      if (rowCount > 0) {
        createTransaction(results.data.data, station)
      }
    })
    .catch((e) => {
      console.log(e)
    })

  // get traffic
  axios
    .post(station.url + '/traffic/search', data, {
      headers: {
        'cache-control': 'no-cache',
        'content-type': 'application/json',
        'postman-token': '99b3a75b-4020-9dff-b94b-b262746069c6',
      },
    })
    .then((results) => {
      const rowCount = results.data.data.length
      if (rowCount > 0) {
        createTraffic(results.data.data, station)
      }
    })
    .catch((e) => {
      console.log(e)
    })
},
  // timer onject for time service management
  timer = {
    time: 15,
    _time: null,
    _timeout: null,
    fun: () => { },
    // trigger start method
    start() {
      if (this._timeout == null) {
        const self = this
        this.fun()
        this._timeout = setTimeout(function repeater() {
          self.fun()
          self._timeout = setTimeout(repeater, 1000 * self.time)
        }, 1000 * this.time)
      }
    },

    // stop services method
    stop() {
      const timeout = this._timeout
      this._timeout = null
      this.set_time()
      clearTimeout(timeout)
    },

    // set time method
    set_time(time) {
      if (this._time == null) this._time = this.time

      if (time) {
        this.time = time
      } else {
        this.time = this._time
      }
    },
  }

// work space function for running inteval time
timer.fun = async () => {
  const station = await Station.find()

  // loop station object
  for (let i = 0; i < station.length; i++) {
    // get station url to 'station' constant variable
    const _station = station[i]

    // if station active true send station url and station object to fetch function
    if (_station.active) {
      fetch(_station)
    }
  }
}

module.exports = timer
