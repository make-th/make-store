const app = require('express').Router()
const {
  getAll,
  create,
  getStationList,
  destroy,
  update,
} = require('./station.service')
const timer = require('./main.process')
const { verifyToken } = require('../middlewares/authJWT')
const { isAdmin } = require('../middlewares/checkPermission')
const { body, validationResult, param } = require('express-validator')
const { logCreate } = require('../services/log.service')

app.get(
  '/station/start-services/:time',
  verifyToken,
  isAdmin,
  param('time', 'Invalid type of time').isNumeric(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const time = parseInt(req.params.time)
      timer.set_time(time)
      timer.start()

      // log create
      logCreate(req, {
        title: 'Fetching services.',
        description: `Services has started, fetching time is ${time} seconds.`,
      })

      return res.status(200).json({
        message: 'services has started.',
        config: {
          time,
          station: await getStationList(),
        },
      })
    } catch (error) {
      return res.status(500).json(error)
    }
  }
)

app.get('/station/stop-services', verifyToken, isAdmin, (req, res) => {
  try {
    timer.stop()

    // log create
    logCreate(req, {
      title: 'Fetching services.',
      description: `Services has stopped.`,
    })

    return res.status(200).json({
      status: 'stopped',
    })
  } catch (error) {
    res.status(500).json(error)
  }
})

app.get('/station/status', verifyToken, isAdmin, async (req, res) => {
  return res.status(200).json({
    status: timer._timeout ? 'running' : 'stopped',
    station: await getStationList(),
  })
})

app.get('/station/get-all', verifyToken, isAdmin, getAll)

app.post(
  '/station/create',
  verifyToken,
  // isAdmin,
  body('name').isString().isLength({ min: 1, max: 200 }),
  body('url').isURL(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      await create(req, res)
    } catch (error) {
      return res.status(500).json(error)
    }
  }
)

app.put(
  '/station/update/:id',
  verifyToken,
  isAdmin,
  param('id').isMongoId(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      // update station method
      await update(req, res)
    } catch (error) {
      return res.status(500).json(error)
    }
  }
)

app.delete(
  '/station/destroy/:id',
  verifyToken,
  isAdmin,
  param('id').isMongoId(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      // delete station metohd
      await destroy(req, res)
    } catch (error) {
      return res.status(500).json(error)
    }
  }
)
module.exports = app
