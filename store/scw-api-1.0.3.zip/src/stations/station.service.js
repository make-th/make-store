const Station = require('../models/Station')
const { logCreate } = require('../services/log.service')

module.exports = {
  getStationList: async () => {
    return await Station.find({}, { __v: 0 })
  },

  getAll: async (req, res) => {
    try {
      const results = await Station.find({}, { __v: 0 })

      if (results.length > 0) {
        return res.status(200).send(results)
      }

      res.status(404).json({
        message: 'Station is not found.',
      })
    } catch (error) {
      return res.status(500).json({
        error,
      })
    }
  },

  create: async (req, res) => {
    try {
      const { name, url } = req.body
      const results = await Station.create({
        name,
        url,
      })

      if (!results) {
        return res.status(400).send('Bad Request!')
      }

      // // log create
      // logCreate(req, {
      //   title: 'Systems.',
      //   description: `${results.name} has been created.`,
      // })

      res.status(201).json({
        stationName: results.name,
        url: results.url,
        active: true,
        message: 'successfully.',
      })
    } catch (error) {
      return res.status(500).json({
        error,
      })
    }
  },

  update: async (req, res) => {
    try {
      const id = req.params.id
      const results = await Station.findByIdAndUpdate(id, req.body)

      if (!results) {
        return res.status(400).send('Bad Request!')
      }

      // log create
      logCreate(req, {
        title: 'Systems.',
        description: `${results.name} update station successfully.`,
      })

      res.status(200).json({
        stationName: results.name,
        message: 'update successfully.',
      })
    } catch (error) {
      return res.status(500).json({
        error,
      })
    }
  },

  destroy: async (req, res) => {
    try {
      const id = req.params.id
      const results = await Station.findByIdAndRemove(id)

      if (!results) {
        return res.status(400).send('Bad Request!')
      }

      // log create
      logCreate(req, {
        title: 'Systems.',
        description: `${results.name} has been deleted.`,
      })

      res.status(200).json({
        stationName: results.name,
        message: 'detele successfully.',
      })
    } catch (error) {
      return res.status(500).json({
        error,
      })
    }
  },
}
