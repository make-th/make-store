const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
  username: { type: String, default: null, required: true },
  password: { type: String, default: null, required: true },
  email: {
    type: String,
    require: true,
    index: true,
    unique: true,
    sparse: true,
  },
  role: { type: String, required: true },
  permission: { type: Array, default: [] },
  lastDate: { type: Date, default: Date.now() },
  status: { type: Boolean, default: true },
})

module.exports = mongoose.model('user', userSchema)
