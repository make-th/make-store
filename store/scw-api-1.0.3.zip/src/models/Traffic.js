const mongoose = require('mongoose')

const Schema = mongoose.Schema
const ObjectId = Schema.ObjectId

const trafficSchema = new mongoose.Schema({
  station: { type: ObjectId, ref: 'Station' },
  stamp: { type: Date },
  count_doc: { type: Number },
  volume: { type: Number },
  speed: { type: Number },
  direction: { type: String },
})

module.exports = mongoose.model('traffic', trafficSchema)
