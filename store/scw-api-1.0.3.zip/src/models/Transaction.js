const mongoose = require('mongoose')

const Schema = mongoose.Schema
const ObjectId = Schema.ObjectId

const transactionSchema = new mongoose.Schema({
  station: { type: ObjectId, ref: 'Station' },
  button: {
    direction: { type: String },
    stamp: { type: Date },
  },
  max_green: {
    stamp: { type: Date },
    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        gap: { type: Number },
        status: { type: Boolean },
        license_plate: { type: String },
        province: { type: String },
      },
    ],
    stage_condition: [
      {
        direction: { type: String },
        lane: { type: Number },
        status: { Boolean },
        stamp: { type: Date },
      },
    ],
    person: [
      {
        direction: { type: String },
        first_stamp: { type: Date },
        last_stamp: { type: Date },
      },
    ],
    person_counting: [
      {
        direction: { type: String },
        stamp: { type: Date },
      },
    ],
  },
  yellow: {
    stamp: { type: Date },
    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        gap: { type: Number },
        status: { type: Boolean },
        license_plate: { type: String },
        province: { type: String },
      },
    ],
    person: [
      {
        direction: { type: String },
        first_stamp: { type: Date },
        last_stamp: { type: Date },
      },
    ],
    person_counting: [
      {
        direction: { type: String },
        stamp: { type: Date },
      },
    ],
  },
  first_all_red: {
    stamp: { type: Date },
    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
      },
    ],
    vehicles_violation: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
      },
    ],
    person: [
      {
        direction: { type: String },
        first_stamp: { type: Date },
        last_stamp: { type: Date },
      },
    ],
    person_counting: [
      {
        direction: { type: String },
        stamp: { type: Date },
      },
    ],
  },
  walk: {
    stamp: { type: Date },
    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        gap: { type: Number },
        status: { type: Boolean },
        license_plate: { type: String },
        province: { type: String },
      },
    ],
    vehicles_violation: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
      },
    ],
    person: [
      {
        direction: { type: String },
        first_stamp: { type: Date },
        last_stamp: { type: Date },
      },
    ],
    person_counting: [
      {
        direction: { type: String },
        stamp: { type: Date },
      },
    ],
  },
  fdw: {
    stamp: { type: Date },
    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        gap: { type: Number },
        status: { type: Boolean },
        license_plate: { type: String },
        province: { type: String },
      },
    ],
    vehicles_violation: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
      },
    ],
    person: [
      {
        direction: { type: String },
        first_stamp: { type: Date },
        last_stamp: { type: Date },
      },
    ],
    person_counting: [
      {
        direction: { type: String },
        stamp: { type: Date },
      },
    ],
  },
  extend: {
    stamp: { type: Date },
    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        gap: { type: Number },
        status: { type: Boolean },
        license_plate: { type: String },
        province: { type: String },
      },
    ],
    vehicles_violation: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
      },
    ],
    person: [
      {
        direction: { type: String },
        first_stamp: { type: Date },
        last_stamp: { type: Date },
      },
    ],
    person_counting: [
      {
        direction: { type: String },
        stamp: { type: Date },
      },
    ],
  },
  last_all_red: {
    stamp: { type: Date },
    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        gap: { type: Number },
        status: { type: Boolean },
        license_plate: { type: String },
        province: { type: String },
      },
    ],
    vehicles_violation: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
      },
    ],
    person_counting: [
      {
        direction: { type: String },
        stamp: { type: Date },
      },
    ],
  },
  end: {
    stamp: { type: Date },
  },
  stamp: { type: Date },
  created_at: { type: Date },
  updated_at: { type: Date },
})

module.exports = mongoose.model('transaction', transactionSchema)
