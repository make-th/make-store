SELECT ID
FROM VIEW_Customers
WHERE status = 1
    AND DATEDIFF(day, DATEADD(day, (SELECT endContractNotification
    FROM System_Config), draftDate), GETDATE()) >= 0 AND DATEDIFF(day, DATEADD(day, (SELECT endContractNotification
    FROM System_Config), draftDate), GETDATE()) <= (SELECT endContractNotification
    FROM System_Config)