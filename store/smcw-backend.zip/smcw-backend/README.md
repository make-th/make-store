# Product - Smart cross walk

## Update .env  

Mongodb - MONGO_URI_ONLINE 
Date - 20211128 / arsit
