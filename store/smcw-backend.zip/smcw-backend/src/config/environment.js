require('dotenv').config()
const { MONGO_URI, MONGO_URI_ONLINE, APP_PORT, PASSWORD_SECRET, JWT_SECRET } =
  process.env

module.exports = {
  MONGO_URI,
  MONGO_URI_ONLINE,
  APP_PORT: APP_PORT || 3000,
  PASSWORD_SECRET,
  JWT_SECRET,
}
