const Traffic = require('../models/Traffic')
const Transaction = require('../models/Transaction')

module.exports = {
  createTraffic: async (data, station) => {
    for (let i = 0; i < data.length; i++) {
      const trf = data[i]
      const results = await Traffic.findOne({ _id: trf._id });
     // console.log('createTraffic',results);
      if (!results) {
        await Traffic.create({
          ...trf,
          station: { id: station._id },
        })
      }
    }
  },

  createTransaction: async (data, station) => {
    for (let i = 0; i < data.length; i++) {
      const trans = data[i]
      const results = await Transaction.findOne({ _id: trans._id })
     // console.log('createTransaction',results);
      if (!results) {
        await Transaction.create({
          ...trans,
          station: { id: station._id },
        })
      }
    }
  },
}
