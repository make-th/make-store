const mongoose = require('mongoose')

const Schema = mongoose.Schema
const ObjectId = Schema.ObjectId

const transactionSchema = new mongoose.Schema({
  station: {
    id: { type: ObjectId },
  },
  button: {
    direction: { type: String },
    stamp: { type: Date },
  },
  max_green: {
    stamp: { type: Date },
    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        gap: { type: Number },
        status: { type: Boolean },
      },
    ],

    stage_condition: [
      {
        direction: { type: String },
        lane: { type: Number },
        status: { Boolean },
        stamp: { type: Date },
      },
    ],

    person: [
      {
        direction: { type: String },
        fitst_stamp: { type: Date },
        last_stamp: { type: Date },
      },
    ],
  },
  yellow: {
    stamp: { type: Date },

    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
      },
    ],
  },
  first_all_red: {
    stamp: { type: Date },

    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        image: { type: String },
        license_plate: { type: String },
        province: { type: String },
      },
    ],
  },
  walk: {
    stamp: { type: Date },

    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        image: { type: String },
        license_plate: { type: String },
        province: { type: String },
      },
    ],

    person: [
      {
        direction: { type: String },
        first_stamp: { type: Date },
        last_stamp: { type: Date },
      },
    ],
  },
  fdw: {
    stamp: { type: Date },

    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        image: { type: String },
        license_plate: { type: String },
        province: { type: String },
      },
    ],

    person: [
      {
        direction: { type: String },
        first_stamp: { type: Date },
        last_stamp: { type: Date },
      },
    ],
  },
  extend: {
    stamp: { type: Date },

    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        image: { type: String },
        license_plate: { type: String },
        province: { type: String },
      },
    ],

    person: [
      {
        direction: { type: String },
        first_stamp: { type: Date },
        last_stamp: { type: Date },
      },
    ],
  },
  last_all_red: {
    stamp: { type: Date },

    vehicles: [
      {
        stamp: { type: Date },
        direction: { type: String },
        lane: { type: Number },
        speed: { type: Number },
        image: { type: String },
        license_plate: { type: String },
        province: { type: String },
      },
    ],
  },
  stamp: { type: Date },
  created_at: { type: Date },
  updated_at: { type: Date },
})

module.exports = mongoose.model('transaction', transactionSchema)
