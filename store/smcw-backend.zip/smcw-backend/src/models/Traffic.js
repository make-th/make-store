const mongoose = require('mongoose')

const Schema = mongoose.Schema
const ObjectId = Schema.ObjectId

const trafficSchema = new mongoose.Schema({
  station: {
    id: { type: ObjectId },
  },
  stamp: { type: Date },
  speed: { type: Number },
  volume: { type: Number },
})

module.exports = mongoose.model('traffic', trafficSchema)
