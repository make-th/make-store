const jwt = require('jsonwebtoken')
const { JWT_SECRET } = require('../config/environment')

module.exports = {
  verifyToken: (req, res, next) => {
 

    // get token from body or query or request header 'x-access-token'
    const token =
      req.body.token || req.query.token || req.headers['x-access-token']||
      req.headers.authorization
      ? req.headers.authorization.split(' ')[1]
      : null
     
    // check if not token response 401 unauthorized
    if (!token) {
      return res.status(401).send('Unauthorized.')
    }
   
    try {
    
      // verify token
      const decoded = jwt.verify(token, JWT_SECRET)
     
      const { user } = decoded
      req.user = user
    } catch (error) {
      // verify token error
      return res.status(403).json({
        status: 'error',
        error,
      })
    }
    next()
  },
}
