const moment = require('moment')
const { v4: uuidv4 } = require('uuid')
const Transaction = require('../models/Transaction')
const Traffic = require('../models/Traffic')

// 1 Dashboard : ข้อมูลแสดงความเร็วเฉลี่ยรถ
const carSpeedAvgByLane = async (start, end, direction) => {
  // find object in database
  const _transactions = await Transaction.find(
    {
      stamp: {
        $gte: new Date(start),
        $lt: new Date(end),
      },
    },
    { 'max_green.vehicles': 1 }
  )

  // remove speed 0 value in array
  let transactionSpeedFilter = await _transactions.map((item) => {
    return {
      ...item.max_green.vehicles.filter(function (val) {
        return val.speed !== 0
      }),
    }
  })

  // destracuture object in array
  let results = []
  for (let key in transactionSpeedFilter) {
    const arr1 = transactionSpeedFilter[key]

    for (let key in arr1) {
      const arr2 = arr1[key]
      results.push(arr2)
    }
  }

  // this gives an object with dates as keys
  const groupDate = results.reduce((groupDate, _) => {
    const date = _.stamp.toISOString().split('T')[0]
    if (!groupDate[date]) {
      groupDate[date] = []
    }
    groupDate[date].push(_)
    return groupDate
  }, {})

  // return array for frontend
  return Object.keys(groupDate).map((date) => {
    const lane1 = average(
      filterArrayByLaneAndDirection(groupDate[date], 1, direction)
    )
    const lane2 = average(
      filterArrayByLaneAndDirection(groupDate[date], 2, direction)
    )
    const lane3 = average(
      filterArrayByLaneAndDirection(groupDate[date], 3, direction)
    )
    const lane4 = average(
      filterArrayByLaneAndDirection(groupDate[date], 4, direction)
    )
    return {
      uuid: uuidv4(),
      date,
      avgSpeed1: lane1,
      avgSpeed2: lane2,
      avgSpeed3: lane3,
      avgSpeed4: lane4,
      side: direction,
    }
  })
}

// 2 Dashboard : ค่าความเร็วรถเฉลี่ย
const carSpeedAvgAll = async (start, end) => {
  // find object by date query
  const traffics = await Traffic.find({
    stamp: {
      $gte: new Date(start),
      $lt: new Date(end),
    },
  })

  // let results = traffics.map((traffic) => {
  //   const dayName = moment(traffic.stamp).format('ddd')
  //   return {
  //     uuid: uuidv4(),
  //     TotelAvg: traffic.speed,
  //     Dayname: dayName,
  //   }
  // })

  // this gives an object with dates as keys
  const groupDate = traffics.reduce((groupDate, _) => {
    const date = _.stamp.toISOString()//.split('T')[0]
    if (!groupDate[date]) {
      groupDate[date] = []
    }
    groupDate[date].push(_)
    return groupDate
  }, {})

  // return array for frontend
  return Object.keys(groupDate).map((date) => {
    const dayName = moment(date).format('ddd')
    return {
      uuid: uuidv4(),
      date,
      dayName,
      TotelAvg: groupDate[date]
        .map((i) => i.speed)
        .reduce((sum, x) => sum + x / groupDate[date].length, 0),
    }
  })
}

// 3 Dashboard : ข้อมูลกราฟแสดงปริมาณจราจรรถที่ฝ่าฝืนบนทางข้าม
const trafficViolationOnCrossWalk = async (start, end) => {
  // find object by date query
  const _transactions = await Transaction.find(
    {
      stamp: {
        $gte: new Date(start),
        $lt: new Date(end),
      },
    },
    { 'walk.stamp': 1, 'walk.vehicles': 1 }
  )

  // this gives an object with dates as keys
  const groups = _transactions.reduce((groups, _) => {
    const date = _.walk.stamp.toISOString()//.split('T')[0]
    if (!groups[date]) {
      groups[date] = []
    }
    groups[date].push(_)
    return groups
  }, {})

  // return object for frontend
  return Object.keys(groups).map((date) => {
    const dayName = moment(date).format('ddd')
    return {
      uuid: uuidv4(),
      date,
      Dayname: dayName,
      // grouping date array
      TotelViolate: groups[date]
        // map for length
        .map((i) => i.walk.vehicles.length)
        // summary array length
        .reduce((sum, x) => sum + x, 0),
    }
  })
}

// 4 Dashboard : ข้อมูลกราฟแสดงปริมาณจราจรแยกประเภทขาเข้าและขาออก
const trafficVolumesByInboundAndOutBound = async (start, end) => {
  // find object in database
  const _transactions = await Transaction.find(
    {
      stamp: {
        $gte: new Date(start),
        $lt: new Date(end),
      },
    },
    { 'max_green.vehicles': 1 }
  )

  // remove speed 0 value in array
  let transactionSpeedFilter = await _transactions.map((item) => {
    return {
      ...item.max_green.vehicles.filter(function (val) {
        return val.speed !== 0
      }),
    }
  })

  // destracuture object in array
  let results = []
  for (let key in transactionSpeedFilter) {
    const arr1 = transactionSpeedFilter[key]

    for (let key in arr1) {
      const arr2 = arr1[key]
      results.push(arr2)
    }
  }

  // this gives an object with dates as keys
  const groupDate = results.reduce((groupDate, _) => {
    const date = _.stamp.toISOString()//.split('T')[0]
    if (!groupDate[date]) {
      groupDate[date] = []
    }
    groupDate[date].push(_)
    return groupDate
  }, {})

  // return array for frontend
  return Object.keys(groupDate).map((date) => {
    const dayName = moment(date).format('ddd')
    const inbound = groupDate[date].filter((i) => i.direction === 'in').length
    const outbound = groupDate[date].filter((i) => i.direction === 'out').length
    return {
      uuid: uuidv4(),
      date,
      TotelLoadIn: inbound,
      TotelLoadOut: outbound,
      Dayname: dayName,
    }
  })
}

// 5 Dashboard : ข้อมูลแสดงปริมาณการใช้ทางอัจฉริยะแบบย่อ
const smartTraffic = async (start, end) => {
  // find object in database
  const _transactions = await Transaction.find(
    {
      stamp: {
        $gte: new Date(start),
        $lt: new Date(end),
      },
    },
    { 'walk.person': 1 }
  )

  let arrayList = _transactions
    .map((item) => {
      return {
        ...item.walk.person,
      }
    })
    .filter((obj) => {
      return ![null, undefined, ''].includes(obj)
    })
    .filter((el) => {
      return typeof el != 'object' || Object.keys(el).length > 0
    })

  let results = []
  for (let key in arrayList) {
    const arr1 = arrayList[key]

    for (let key in arr1) {
      const arr2 = arr1[key]
      results.push(arr2)
    }
  }

  // this gives an object with dates as keys
  const groupDate = results.reduce((groupDate, _) => {
    const date = _.first_stamp.toISOString()//.split('T')[0]
    if (!groupDate[date]) {
      groupDate[date] = []
    }
    groupDate[date].push(_)
    return groupDate
  }, {})

  // return array for frontend
  return Object.keys(groupDate).map((date) => {
    const dayName = moment(date).format('ddd')
    const inbound = groupDate[date].filter((i) => i.direction === 'in').length
    const outbound = groupDate[date].filter((i) => i.direction === 'out').length
    return {
      uuid: uuidv4(),
      date,
      TotelPeple: results.length,
      TotelPepleIn: inbound,
      TotelPepleOut: outbound,
    }
  })
}

// function for calcucate average
function average(arrayItem) {
  let len = arrayItem.length
  let summary = arrayItem.reduce((sum, x) => sum + x.speed, 0)
  let results = summary / len ? summary / len : 0
  return results
}

// function for filter array by lane and direction
function filterArrayByLaneAndDirection(arrayItem, _lane, _direction) {
  return arrayItem.filter((i) => i.lane === _lane && i.direction === _direction)
}
module.exports = {
  carSpeedAvgByLane,
  carSpeedAvgAll,
  trafficViolationOnCrossWalk,
  trafficVolumesByInboundAndOutBound,
  smartTraffic,
}
