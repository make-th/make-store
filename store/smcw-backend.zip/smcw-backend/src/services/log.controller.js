const app = require('express').Router()

const { verifyToken } = require('../middlewares/authJWT')
const {list} = require('./log.service');
const {isAdmin} = require('../middlewares/checkPermission');


app.get('/log/list',verifyToken,isAdmin,list);

module.exports = app