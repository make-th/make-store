const jwt = require('jsonwebtoken')
const { JWT_SECRET } = require('../config/environment')
const Log = require('../models/Log')

async function getUserIdByToken(req) {
  try {
    const token =
      req.body.token ||
        req.query.token ||
        req.headers['x-access-token']
        ||
        req.headers.authorization
        ? req.headers.authorization.split(' ')[1]
        : null
    const decode = await jwt.verify(token, JWT_SECRET)
    return decode.user._id
  } catch (error) {
    console.log(error)
  }
}

const create = async (req, { title, description }) => {
  try {
    const userId = await getUserIdByToken(req)
    await Log.create({
      title,
      description,
      updatedBy: userId,
    })
  } catch (error) {
    console.log(error)
  }
}


module.exports = {
  logCreate: create,
  list: async (req, res) => {
    try {
      const results = await Log.find({}, { __v: 0 });
      console.log(results)
      if (results.length > 0) {
        return res.status(200).send(results);
      }

      // res.status(404).json({
      //   message:"Log in not found."
      // })
    } catch (error) {
      return res.status(500).json({
        error
      })
    }
  }
}
