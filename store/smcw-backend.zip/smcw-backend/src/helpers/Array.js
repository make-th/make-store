module.exports = {
  average: (arr) => {
    const items = arr.filter((item) => item !== 0)
    if (items.length > 0) {
      return items.reduce((p, c) => p + c, 0) / items.length
    }
    return 0
  },
}
