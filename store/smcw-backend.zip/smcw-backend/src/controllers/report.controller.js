const route = require('express').Router()
const { body, validationResult } = require('express-validator')
const { verifyToken } = require('../middlewares/authJWT')

// Report :  ข้อมูลกราฟแสดงปริมาณจราจรแยกประเภทขาเข้าขาออก ( SummaryTraffic)
route.post(
  '/reports/summary-traffic',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  body('side').isIn(['in', 'out']),
  body('type').isIn(['Hour', 'Day', 'Week', 'Month']),
  body('station').isMongoId(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end, direction } = req.body
      //const results = await carSpeedAvgByLane(start, end, direction)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(500).json(error)
    }
  }
)

module.exports = route
