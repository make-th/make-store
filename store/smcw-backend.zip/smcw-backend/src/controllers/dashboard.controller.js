const app = require('express').Router()
const { body, validationResult } = require('express-validator')
const { verifyToken } = require('../middlewares/authJWT')
const {
  carSpeedAvgByLane,
  carSpeedAvgAll,
  trafficViolationOnCrossWalk,
  trafficVolumesByInboundAndOutBound,
  smartTraffic,
} = require('../services/dashboard.service')

// 1 Dashboard : ข้อมูลแสดงความเร็วเฉลี่ยรถ
app.post(
  '/dashboard/car-speed-avg-by-lane',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  body('direction').isIn(['in', 'out']),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end, direction } = req.body
      const results = await carSpeedAvgByLane(start, end, direction)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(500).json(error)
    }
  }
)

// 2 Dashboard : ค่าความเร็วรถเฉลี่ย
app.post(
  '/dashboard/car-speed-avg-all',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end } = req.body
      const results = await carSpeedAvgAll(start, end)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(500).json(error)
    }
  }
)

// 3 Dashboard : ข้อมูลกราฟแสดงปริมาณจราจรรถที่ฝ่าฝืนบนทางข้าม
app.post(
  '/dashboard/traffic-violation',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end } = req.body
      const results = await trafficViolationOnCrossWalk(start, end)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(500).json(error)
    }
  }
)

// 4 Dashboard : ข้อมูลกราฟแสดงปริมาณจราจรแยกประเภทขาเข้าและขาออก
app.post(
  '/dashboard/traffic-volumes',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end } = req.body
      const results = await trafficVolumesByInboundAndOutBound(start, end)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(500).json(error)
    }
  }
)

// 5 Dashboard : ข้อมูลแสดงปริมาณการใช้ทางอัจฉริยะแบบย่อ
app.post(
  '/dashboard/smart-traffic',
  verifyToken,
  body('start').isISO8601().toDate(),
  body('end').isISO8601().toDate(),
  async (req, res) => {
    try {
      //validation
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { start, end } = req.body
      const results = await smartTraffic(start, end)

      return res.send(results)
    } catch (error) {
      console.log(error)
      return res.status(500).json(error)
    }
  }
)
module.exports = app
