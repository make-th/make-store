const { verifyToken } = require('../middlewares/authJWT')
const User = require('../models/User')
const { register, login, me } = require('../services/auth.service')
const route = require('express').Router()
const { body, validationResult } = require('express-validator')

route.post(
  '/auth/register',
  body('username').isString().isLength({ min: 5 }),
  body('password').isString().isLength({ min: 8 }),
  body('email').isEmail().isLength({ min: 1 }),
  body('role').isString().isLength({ min: 1 }),
  body('permission').isArray(),
  async (req, res) => {
    // validation
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const { username, password, email, role, permission } = req.body

    // validate object
    if (!(username && password && email && role && permission)) {
      return res.status(400).send('All input is requried.')
    }

    // check duplicate username
    const duplicateUsername = await User.findOne({ username })
    if (duplicateUsername) {
      return res.status(409).send('Username is already exist.')
    }

    // check duplicate email
    const duplicateEmail = await User.findOne({ email })
    if (duplicateEmail) {
      return res.status(409).send('Email is already exist.')
    }

    // use services for create new users
    register(req, res)
  }
)

route.post(
  '/auth/login',
  body('username').isString().isLength({ min: 5 }),
  body('password').isString().isLength({ min: 8 }),
  async (req, res) => {
    // validation
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    const { username } = req.body

    const user = await User.findOne({ username })
    if (user) {
      return login(req, res)
    }

    return res.status(404).send('Invalid credentials.')
  }
)

route.get('/auth/me', verifyToken, me)

route.post('/auth/list',verifyToken,async(req,res)=>{

  // validation

  const errors = validationResult(req);

  if(!errors.isEmpty()){
    return res.status(400).json({errors:errors.array()});
  }

  const user = await User.find({},{__v:0});

  let list =[];

  user.map(function(e){
    list.push({
      username:e.username,
      email:e.email,
      role:e.role,
      active:e.status,
      permission:e.permission
    })
  })

  if (user) {
    return res.status(200).send(list);
  }

  return res.status(404).send("Invalid credentials");

});

module.exports = route
